<script setup lang="ts">
import Login from '../components/Login.vue';
</script>

<template>
  <div id="photo">
   
  </div>
  <Login></Login>
</template>


<style scoped>
.logo{ height: 20em;
}
#photo{ text-align: center;
    background-color: #fff;
    border-radius: 20px;
    width: 300px;
    height: 300px;
    margin: auto;
    position: absolute;
    top: 15%;
    left: 0;
    right: 70%;
    bottom: 30%;}
</style>
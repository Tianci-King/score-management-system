export interface Score {
    name: String,
    grade: String,
}
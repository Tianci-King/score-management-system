<script setup lang="ts">
  import { RouterView } from "vue-router";
</script>

<template>
 <router-view name="right"></router-view>
 <RouterView></RouterView>
</template>


